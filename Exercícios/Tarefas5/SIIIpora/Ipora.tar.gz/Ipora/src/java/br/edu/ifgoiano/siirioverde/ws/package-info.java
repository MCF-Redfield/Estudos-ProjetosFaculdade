@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.siirioverde.ifgoiano.edu.br/")
package br.edu.ifgoiano.siirioverde.ws;
